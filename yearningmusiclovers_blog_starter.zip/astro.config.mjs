import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://yearningmusiclovers.vercel.app',
});
