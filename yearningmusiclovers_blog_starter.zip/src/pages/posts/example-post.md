---
title: "Mixtape Entry: June Softcore Vibes"
date: 2025-06-10
spotify: "https://open.spotify.com/embed/track/xyz"
---

Today’s mood: shoes untied, headphones on, walking with purpose but going nowhere.

- Mazzy Star – *Fade Into You*
- Radiohead – *Let Down*
- Beach House – *Take Care*

> “The summer air feels heavier when you’re missing someone who doesn’t exist anymore.”

---

<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/xyz" width="100%" height="152" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
