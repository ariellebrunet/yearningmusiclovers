module.exports = {
  content: ['./src/**/*.{astro,html,js,md}'],
  theme: {
    extend: {
      fontFamily: {
        serif: ['EB Garamond', 'serif'],
      },
    },
  },
  plugins: [],
};
